package OCPWrong;

public class CompanyManagement {

	public void callUpon(Employee employee) {
		if (employee instanceof HumanResources) {
			approvedVocational();
		} else if (employee instanceof Develpment) {
			developSystem();
		}
	}

	// HumanResources
	private void approvedVocational() {
		System.out.print("this method to approve or reject Vocational");
	}

	// Develpment
	private void developSystem() {
		System.out.print("this method to developSystem");
	}

}
