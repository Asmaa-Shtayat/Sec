package OCPWrong;

public class Develpment extends Employee {

	public Develpment(int id, String name, String department, boolean working) {
		super(id, name, department, working);
		System.out.println("Develpment Employee ..");
	}

}
