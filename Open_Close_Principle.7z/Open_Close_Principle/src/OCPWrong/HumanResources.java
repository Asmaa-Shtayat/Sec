package OCPWrong;

public class HumanResources extends Employee {

	public HumanResources(int id, String name, String department,
			boolean working) {
		super(id, name, department, working);
		System.out.println("HumanResources Employee ..");
	}

}
