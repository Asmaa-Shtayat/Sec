package OCPCorrect;

public class Testing {

	public static void main(String[] args) {
		CompanyManagement director = new CompanyManagement();

		Employee employeeHR = new HumanResources(101, "Ahmad",
				"HumanResources", true);
		director.callUpon(employeeHR);

		Employee employeeDev = new HumanResources(101, "Muna", "Develpment",
				true);
		director.callUpon(employeeDev);
	}
}
