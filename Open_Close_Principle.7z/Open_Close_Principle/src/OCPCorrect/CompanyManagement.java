package OCPCorrect;

public class CompanyManagement {

	public void callUpon(Employee employee) {
		employee.performDuties();
	}

}
