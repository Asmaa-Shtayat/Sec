package OCPCorrect;

public class HumanResources extends Employee {

	public HumanResources(int id, String name, String department,
			boolean working) {
		super(id, name, department, working);
		System.out.println("HumanResources Employee ..");
	}

	// HumanResources
	private void approvedVocational() {
		System.out.print("this method to approve or reject Vocational");
	}

	@Override
	public void performDuties() {
		approvedVocational();
	}
}
